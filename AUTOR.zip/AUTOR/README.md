# AUTOR

1. create application.properties file in /src/main - 
```
#Database connection details
username = <>
password = <>
```

2. add ojdbc8.jar in /lib folder 

* copy from /afs/eos.ncsu.edu/software/oracle12/oracle/product/12.2/client/jdbc/lib/ojdbc8.jar location on eos server
```
cd /afs/eos.ncsu.edu/software/oracle12/oracle/product/12.2/client/jdbc/lib
cp ojdbc8.jar /afs/unity.ncsu.edu/users/<initial>/<unityId>/DBMS/Project/AUTOR/lib
```


