package main.models;

public interface Role {
    public static final String ADMIN = "Admin";
    public static final String MANAGER = "Manager";
    public static final String CUSTOMER = "Customer";
    public static final String RECEPTIONIST = "Receptionist";
    public static final String MECHANIC = "Mechanic";
}
