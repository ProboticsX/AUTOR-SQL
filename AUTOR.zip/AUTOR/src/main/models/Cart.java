package main.models;

public class Cart {
    public Cart(){

    }
}
