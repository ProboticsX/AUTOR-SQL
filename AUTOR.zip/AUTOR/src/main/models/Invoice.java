package main.models;

public class Invoice {
    public Invoice(){

    }
}
