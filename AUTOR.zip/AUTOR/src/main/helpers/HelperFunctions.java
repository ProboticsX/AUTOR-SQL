package main.helpers;

public class HelperFunctions {

    public static void printStatus(boolean result) {
        if(result){
            System.out.println("SUCCESS");
        }else{
            System.out.println("FAIL");
        }
    }
}
